namespace ESUNAPI.DTOs;
public class TestTableADto {
    public string 公司代號 { get; set; }
    public string 出表日期 { get; set; }
    public string 資料年月 { get; set; }
    public string 公司名稱 { get; set; }
    public string 產業別 { get; set; }
    public long 當月營收 { get; set; }
    public long 上月營收 { get; set; }
    public long 去年當月營收 { get; set; }
    public double 上月比較增減 { get; set; }
    public double 去年同月增減 { get; set; }
    public long 當月累計營收 { get; set; }
    public long 去年累計營收 { get; set; }
    public double 前期比較增減 { get; set; }
    public string 備註 { get; set; }
}