
using AutoMapper;
using ESUNAPI.DTOs;
using ESUNAPI.Models;

namespace ESUNAPI.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<TestTableA, TestTableADto>().ReverseMap();
        }
    }
}
